NeuralTalk2 demo
================

This demo uses NeuralTalk2 captioning code from Andrej Karpathy: https://github.com/karpathy/neuraltalk2

The code captions live webcam demo. Follow the installation instructions at
https://github.com/karpathy/neuraltalk2 first and then run the demo as:

```
th videocaptioning.lua -gpuid -1 -model model_id1-501-1448236541_cpu.t7
```
